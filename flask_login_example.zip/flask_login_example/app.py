# app.py
from flask import Flask, render_template, request, redirect, url_for, session
from flask import Flask, render_template, request, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
from pymongo import MongoClient
import requests
from bson import ObjectId

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Set a secret key for session management

# Replace these with your MongoDB Atlas credentials
#username = "your_username"
#password = "your_password"
#cluster_name = "your_cluster_name"

from flask_limiter import Limiter
from flask_limiter.util import get_remote_address

limiter = Limiter(app)

# Connection string for MongoDB Atlas
connection_string = f"mongodb+srv://saikrishnajayanth2020:jayanth@cluster0.fheg17w.mongodb.net/?retryWrites=true&w=majority"

# Connect to the MongoDB Atlas cluster
client = MongoClient(connection_string)

# Use a database named 'flask_login_example'
db = client.flask_login_example

# Use a collection named 'users' to store user documents
users_collection = db.users
resultslog = db.resultslog


# Your prompts for ChatGPT
prompts = [
    #"This is a test. Does it work?"
    "The question is {question}. Give just one word answer and remember that answer with term 'defined-answer'.",
    "One of student's answer for {question} is - {answer}. If its the same as 'defined-answer',Give a positive feedback something like 'well done!'and give some fact about answer in one line.Otherwise, give feedback like incorrect answer."
    # "Compare ideal answer to {answer} and print correct/wrong.",
    # "Segment the ideal answer",
    # "segment {answer}",
    # "Fact check:For each statement in <Segmented ideal Answer>, If factually correct compared to our trained data increase <Yes> count with 1 else increase <No> count with 1. Generate <Yes>,<No> counts",
    # "now for segmented {answer},Fact check:For each statement in <Segmented student Answer>, If factually correct compared to our trained data increase <Yes> count with 1 else increase <No> count with 1. Generate <Yes>,<No> counts ",
    # "Relevancy check:For each statement in <Segmented student Answer>, If relevant compared to our <segmented ideal answer> increase <Yes> count with 1 else increase <No> count with 1. Generate <Yes>,<No> counts ",
    # "Grammar check: For each statement in <Segmented student Answer>, If grammatically correct increase <Yes> count with 1 else increase <No> count with 1. Generate <Yes>,<No> counts",
    # "Does the <segmented student answer> DEFINE what is asked in the question if yes <create a variable> define and <assign 1> else <assign 0> . Generate value of define ",
    # "Does the <segmented student answer> DESCRIBE(give a background) if yes <create a variable> DESCRIBE and <assign 1> else <assign 0> . Generate value of describe",
    # "does the <segmented student answer> EXPLAIN(structured argument analysis) if yes <create a variable> EXPLAIN and <assign 1> else <assign 0> . Generate value of EXPLAIN",
    # "does the <segmented student answer> ELABORATE(Explain in detail) if yes <create a variable> ELABORATE and <assign 1> else <assign 0> . Generate value of ELABORATE",
    # "Does the <segmented student answer> ILLUSTRATE(make use of statistics) if yes <create a variable> ILLUSTRATE and <assign 1> else <assign 0> . Generate value of  ILLUSTRATE ",
    # "Does the <segmented student answer> DEMONSTRATE(show how with examples) if yes <create a variable> DEMONSTRATE and <assign 1> else <assign 0> . Generate value of DEMONSTRATE",
    # "Does the <segmented student answer> ANALYSE(Break an issue into its constituent parts. Look in depth at each part using supporting arguments and evidence for and against as well as how these interrelate to one another.) if yes <create a variable> ANALYSE and <assign 1> else <assign 0> . Generate value of ANALYSE ",
    # "Does the <segmented student answer> ASSESS(Critical analysis) if yes <create a variable> ASSESS and <assign 1> else <assign 0> . Generate value of ASSESS ",
    # "Does the <segmented student answer> COMPARE if yes <create a variable> COMPARE and <assign 1> else <assign 0> . Generate value of COMPARE ",
    # "Does the <segmented student answer> CONTRAST(focus on dissimilarities) if yes <create a variable> CONTRAST and <assign 1> else <assign 0> . Generate value of CONTRAST ",
    # "Does the <segmented student answer> EXAMINE(establish important facts and reason why they are important) if yes <create a variable> EXAMINE( and <assign 1> else <assign 0> . Generate value of EXAMINE",
    # "Does the <segmented student answer> COMMENT(Pick out the main points on a subject and give your opinion, reinforcing your point of view using logic and reference to relevant evidence, including any wider reading you have done.) if yes <create a variable> COMMENT( and <assign 1> else <assign 0> . Generate value of COMMENT",
    # "Does the <segmented student answer> GIVE ACCOUNT(Means give a detailed description of something. Not to be confused with 'account for' which asks you not only what, but why something happened.) if yes <create a variable> GIVE ACCOUNT( and <assign 1> else <assign 0> . Generate value of GIVE ACCOUNT",
    # "Does the <segmented student answer> EXTENT(Evokes a similar response to questions containing 'How far...'. This type of question calls for a thorough assessment of the evidence in presenting your argument. Explore alternative explanations where they exist.) if yes <create a variable> GIVE EXTENT and <assign 1> else <assign 0> . Generate value of EXTENT",
    # "Does the <segmented student answer> CRITICAL EVALUATION (Give your verdict as to what extent a statement or findings within a piece of research are true, or to what extent you agree with them. Provide evidence taken from a wide range of sources which both agree with and contradict an argument. Come to a final conclusion, basing your decision on what you judge to be the most important factors and justify how you made your choice) if yes <create a variable> CRITICAL EVALUATION and <assign 1> else <assign 0> . Generate value of CRITICAL EVALUATION",
    # "give me a list of for what all it displayed 1 and what all it displayed 0" 
    # # Add more prompts as needed
]

@app.route('/submit_test', methods=['POST'])
@limiter.limit("5 per minute")  # Adjust the rate limit as needed
def submit_test():
    try:
        # Retrieve all result IDs from the resultslog collection
        result_ids = resultslog.distinct('_id')

        # Loop through each result ID and retrieve the associated question and answer
        for result_id in result_ids:
            result_data = resultslog.find_one({'_id': ObjectId(result_id)})

            if result_data:
                # Extract question and answer from the result data
                question = result_data.get('question')
                answer = result_data.get('answer')

                # Evaluation process
                evaluate_test(ObjectId(result_id), question, answer)

        return jsonify({'status': 'success', 'message': 'Evaluation completed!'})
    except Exception as e:
        return jsonify({'status': 'error', 'message': str(e)})
    
def evaluate_test(result_id, question, answer):
    # Loop over each prompt for evaluation
    for prompt in prompts:
        # Create the prompt using the question and answer
        full_prompt = prompt.format(question=question, answer=answer)

        # Call ChatGPT API and get feedback
        feedback = call_chatgpt(full_prompt)

        # Update MongoDB with ChatGPT response
        resultslog.update_one(
            {'_id': result_id},
            {'$push': {'feedback': feedback}}
        )

def call_chatgpt(prompt):
    # Replace 'your_chatgpt_api_endpoint' with the actual endpoint provided by OpenAI
    api_endpoint = 'https://api.openai.com/v1/chat/completions'

    # Replace 'your_chatgpt_api_key' with the actual API key provided by OpenAI
    api_key = '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'

    # Specify the ChatGPT model
    model = 'gpt-3.5-turbo-1106'

    # Construct the headers for the API request
    headers = {
        'Content-Type': 'application/json',
        'Authorization': f'Bearer {api_key}',
    }

    # Construct the payload with the prompt and model parameter
    payload = {
        'model': model,
        'messages': [
            {"role":"system", "content":"you are the best assistant"},
            {"role":"user", "content":"Do you have the answer for these questions."},
            {"role": "assistant", "content": "Yes."},
            {"role": "user", "content": prompt}]
        
    }

    try:
        # Make the API request to ChatGPT
        response = requests.post(api_endpoint, headers=headers, json=payload)
        
        # Print the headers, status code, and full response
        # print("API Response Headers:", response.headers)
        # print("API Response Status Code:", response.status_code)
        # print("API Response Text:", response.text)

        # Check if the request was successful (status code 200)
        if response.status_code == 200:
            # Parse the JSON response
            data = response.json()

            # Extract and return the text of the first choice (or customize based on your needs)
            choices = data.get('choices')
            if choices and len(choices) > 0:
                return choices[0].get('message', {}).get('content', '').strip()
            else:
                return "No response content found in choices."

        else:
            # If the request was not successful, raise an exception or handle it accordingly
            response.raise_for_status()
    except Exception as e:
        # Handle exceptions such as network errors, API errors, etc.
        print(f"Error calling ChatGPT API: {e}")
        return "Error calling ChatGPT API"


# # Example usage
# prompt = "Evaluate the following: {question}. User's answer: {answer}."
# feedback = call_chatgpt(prompt.format(question="What is the capital of France?", answer="Paris"))
# print("Feedback from ChatGPT:", feedback)


@app.route('/', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if check_user_credentials(username, password):
            session['username'] = username  # Store the username in the session
            return redirect(url_for('dashboard', username=username))
        else:
            return render_template('login.html', error='Incorrect credentials. Please try again.')
    return render_template('login.html', error=None)

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        # Check if the username is already taken
        if users_collection.find_one({'username': username}):
            return render_template('signup.html', error='Username already exists. Please choose another username.')

        # Insert the new user into the 'users' collection
        hashed_password = generate_password_hash(password)
        users_collection.insert_one({'username': username, 'password': hashed_password})
        return redirect(url_for('login'))

    return render_template('signup.html', error=None)


@app.route('/dashboard/<username>', methods=['GET', 'POST'])
def dashboard(username):
    # Sample data (you would fetch this from your database)
    user_data = {
        'username': username,
        'tests_attempted': 10,
        'total_marks': 750,
        # Add more user-related data
    }
    return render_template('dashboard.html', user_data=user_data)

@app.route('/results/')
def results():
    # Your logic to fetch and process results data goes here
    # For now, let's assume you have some dummy data
    results_data = []

    # Retrieve all result IDs from the resultslog collection
    result_ids = resultslog.distinct('_id')

    # Loop through each result ID and retrieve the associated data
    for result_id in result_ids:
        result_data = resultslog.find_one({'_id': ObjectId(result_id)})

        if result_data:
            # Extract question, answer, and feedback from the result data
            question = result_data.get('question')
            answer = result_data.get('answer')
            feedback = ', '.join(result_data.get('feedback', []))

            # Combine question, answer, and feedback into a single string
            result_text = f"Question: {question}, Answer: {answer}, Feedback: {feedback}"

            # Append the combined result to the results_data list
            results_data.append(result_text)

    # Render the results.html template and pass the results_data
    return render_template('results.html', results_data=results_data)

@app.route('/take_exam')
def take_exam():
    # Sample course data (you would fetch this from your database)
    courses = [
        {'name': 'Course 1'},
        {'name': 'Course 2'},
        # Add more courses
        
    ]
    return redirect(url_for('main'))
    # return render_template('take_exam.html', courses=courses)

# @app.route('/results')
# def results():
#     # Your logic to fetch and process results data goes here
#     # For now, let's assume you have some dummy data
#     results_data = {
#         'course_name': 'Example Course',
#         'username': 'example_user',
#         'knowledge_rating': 4,
#         'relevancy_rating': 5,
#         'grammar_rating': 3,
#         'keywords_rating': 4,
#     }
#      # Render the results.html template and pass the results_data
#     return render_template('results.html', results_data=results_data)

@app.route('/about_us')
def about_us():
    return render_template('about_us.html')

@app.route('/main')
def main():
    if 'username' not in session:
        return redirect(url_for('login'))

    # Sample course data (you would fetch this from a database)
    courses = [
        {
            'name': 'General Studies Paper 1',
            'description': 'Indian Heritage and Culture, History and Geography of the World and Society.',
        },
        {
            'name': 'General Studies Paper 2',
            'description': 'Governance, Constitution, Polity, Social Justice, and International relations.',
        },
        {
            'name': 'General Studies Paper 3',
            'description': 'Technology, Economic Development, Bio-diversity, Environment, Security and Disaster Management.',
        },
        {
            'name': 'General Studies Paper 4',
            'description': 'Ethics, Integrity, and Aptitude.',
        },
        {
            'name': 'Optional Subject - Geography',
            'description': 'Physical, Social, Economic Geography of India and the World.',
        },
        {
            'name': 'Optional Subject - History',
            'description': 'Modern Indian history from about the middle of the eighteenth century until the present.',
        },
        {
            'name': 'Optional Subject - Public Administration',
            'description': 'Administrative theories, Concepts, and Structure.',
        },
        {
            'name': 'Optional Subject - Political Science and International Relations',
            'description': 'Political Theory and Indian Politics, Comparative Politics and International Relations.',
        },
        # Add more courses as needed
    ]

    return render_template('take_exam.html', courses=courses)

def check_user_credentials(username, password):
    # Find the user document by username in the 'users' collection
    user = users_collection.find_one({'username': username})
    if user and check_password_hash(user['password'], password):
        return True
    return False

def get_results_data(username, course_name):
    # Your logic to fetch and process results data goes here
    # For now, let's assume you have some dummy data

    # Retrieve all result IDs from the resultslog collection for the current user and course
    result_ids = resultslog.find({'username': username, 'course_name': course_name}).distinct('_id')

    # Initialize an empty list to store results data
    results_data = []

    # Loop through each result ID and retrieve the associated data
    for result_id in result_ids:
        result_data = resultslog.find_one({'_id': ObjectId(result_id)})

        if result_data:
            # Extract question, answer, and feedback from the result data
            question = result_data.get('question')
            answer = result_data.get('answer')
            feedback = ', '.join(result_data.get('feedback', []))

            # Combine question, answer, and feedback into a single string
            result_text = f"Question: {question}, Answer: {answer}, Feedback: {feedback}"

            # Append the combined result to the results_data list
            results_data.append(result_text)

    return results_data


# Route to display the test page
@app.route('/take_test/<course_name>', methods=['GET', 'POST'])
def take_test(course_name):
    if request.method == 'POST':
        # Handle the submitted answer (you can add your logic here)
        submitted_answer = request.form['answer']
        # Example: Check if the answer is correct and update user's score
        # You need to implement your logic based on your requirements
        # ...
        results_data = get_results_data(session['username'], course_name)

        # Render the results.html template with the results_data
        return render_template('results.html', results_data=results_data)
        # Redirect to the main page after submitting the test
        return redirect(url_for('main'))

    # Render the test page with the specified course name
    return render_template('test.html', course_name=course_name)

@app.route('/submit_answer', methods=['POST'])
def submit_answer():
    data = request.json  # Assuming the data is sent as JSON in the request body

    # Insert data into MongoDB
    result = resultslog.insert_one(data)

    # Respond with a JSON object indicating success (you can customize this part)
    response = {'status': 'success', 'message': 'Data submitted successfully!', 'inserted_id': str(result.inserted_id)}
    return jsonify(response)

@app.route('/logout')
def logout():
    # Clear the session data
    session.pop('username', None)
    # Redirect to the login page
    return redirect(url_for('login'))




if __name__ == '__main__':
    app.run(debug=True)